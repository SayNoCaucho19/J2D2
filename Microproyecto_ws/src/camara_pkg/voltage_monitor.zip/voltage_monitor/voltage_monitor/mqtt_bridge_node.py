#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from std_msgs.msg import Float32
import paho.mqtt.client as mqtt
import json


class MQTTBridgeNode(Node):
    def __init__(self):
        super().__init__('mqtt_bridge_node')
        
        # Declarar parámetros
        self.declare_parameter('broker', 'localhost')
        self.declare_parameter('port', 1883)
        self.declare_parameter('topic', 'sensor/voltage')
        self.declare_parameter('qos', 1)
        
        # Obtener parámetros
        self.broker = self.get_parameter('broker').value
        self.port = self.get_parameter('port').value
        self.mqtt_topic = self.get_parameter('topic').value
        self.qos = self.get_parameter('qos').value
        
        # Publisher ROS2
        self.voltage_pub = self.create_publisher(Float32, 'voltage_data', 10)
        
        # Cliente MQTT
        self.mqtt_client = mqtt.Client()
        self.mqtt_client.on_connect = self.on_connect
        self.mqtt_client.on_message = self.on_message
        
        # Conectar a broker MQTT
        try:
            self.mqtt_client.connect(self.broker, self.port, 60)
            self.mqtt_client.loop_start()
            self.get_logger().info(f'Conectado a MQTT broker: {self.broker}:{self.port}')
        except Exception as e:
            self.get_logger().error(f'Error conectando a MQTT: {str(e)}')
    
    def on_connect(self, client, userdata, flags, rc):
        if rc == 0:
            self.get_logger().info(f'Suscrito al topic: {self.mqtt_topic}')
            client.subscribe(self.mqtt_topic, self.qos)
        else:
            self.get_logger().error(f'Conexión fallida. Código: {rc}')
    
    def on_message(self, client, userdata, msg):
        try:
            # Decodificar mensaje
            payload = msg.payload.decode('utf-8')
            
            # Intentar parsear como JSON o float directo
            try:
                data = json.loads(payload)
                voltage = float(data.get('voltage', data))
            except:
                voltage = float(payload)
            
            # Publicar en ROS2
            msg_ros = Float32()
            msg_ros.data = voltage
            self.voltage_pub.publish(msg_ros)
            
            self.get_logger().info(f'Voltaje recibido: {voltage:.2f}V')
            
        except Exception as e:
            self.get_logger().error(f'Error procesando mensaje: {str(e)}')
    
    def destroy_node(self):
        self.mqtt_client.loop_stop()
        self.mqtt_client.disconnect()
        super().destroy_node()


def main(args=None):
    rclpy.init(args=args)
    node = MQTTBridgeNode()
    
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()