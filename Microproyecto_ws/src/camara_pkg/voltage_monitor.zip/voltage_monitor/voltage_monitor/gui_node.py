#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from std_msgs.msg import Float32
import sys
from PyQt5.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout, 
                             QHBoxLayout, QLabel, QFrame)
from PyQt5.QtCore import Qt, QTimer, pyqtSignal, QObject
from PyQt5.QtGui import QFont, QPalette, QColor
import matplotlib
matplotlib.use('Qt5Agg')
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg
from matplotlib.figure import Figure


class ROSSignals(QObject):
    voltage_signal = pyqtSignal(float)


class VoltageGUINode(Node):
    def __init__(self, signals):
        super().__init__('voltage_gui_node')
        self.signals = signals
        
        # Subscriber
        self.voltage_sub = self.create_subscription(
            Float32,
            'voltage_data',
            self.voltage_callback,
            10
        )
        
        self.get_logger().info('Nodo GUI iniciado')
    
    def voltage_callback(self, msg):
        self.signals.voltage_signal.emit(msg.data)


class VoltageChart(FigureCanvasQTAgg):
    def __init__(self, parent=None):
        self.fig = Figure(figsize=(8, 4), facecolor='#1e1e1e')
        self.ax = self.fig.add_subplot(111)
        super().__init__(self.fig)
        
        self.data = []
        self.max_points = 50
        
        # Estilo
        self.ax.set_facecolor('#2d2d2d')
        self.ax.tick_params(colors='white')
        self.ax.spines['bottom'].set_color('white')
        self.ax.spines['left'].set_color('white')
        self.ax.spines['top'].set_visible(False)
        self.ax.spines['right'].set_visible(False)
        self.ax.set_xlabel('Muestras', color='white')
        self.ax.set_ylabel('Voltaje (V)', color='white')
        self.ax.grid(True, alpha=0.2, color='white')
        
    def update_chart(self, voltage):
        self.data.append(voltage)
        if len(self.data) > self.max_points:
            self.data.pop(0)
        
        self.ax.clear()
        self.ax.plot(self.data, color='#00ff00', linewidth=2)
        self.ax.set_facecolor('#2d2d2d')
        self.ax.tick_params(colors='white')
        self.ax.spines['bottom'].set_color('white')
        self.ax.spines['left'].set_color('white')
        self.ax.spines['top'].set_visible(False)
        self.ax.spines['right'].set_visible(False)
        self.ax.set_xlabel('Muestras', color='white')
        self.ax.set_ylabel('Voltaje (V)', color='white')
        self.ax.grid(True, alpha=0.2, color='white')
        
        self.draw()


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.voltage = 0.0
        self.history = []
        
        self.setWindowTitle('Monitor de Voltaje FZ0430')
        self.setGeometry(100, 100, 900, 700)
        
        # Widget central
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        layout = QVBoxLayout(central_widget)
        
        # Estilo oscuro
        self.setStyleSheet("""
            QMainWindow {
                background-color: #1e1e1e;
            }
            QLabel {
                color: white;
            }
            QFrame {
                background-color: #2d2d2d;
                border-radius: 10px;
                padding: 20px;
            }
        """)
        
        # Título
        title = QLabel('Monitor de Voltaje FZ0430')
        title.setFont(QFont('Arial', 24, QFont.Bold))
        title.setAlignment(Qt.AlignCenter)
        layout.addWidget(title)
        
        # Display de voltaje
        voltage_frame = QFrame()
        voltage_layout = QVBoxLayout(voltage_frame)
        
        voltage_label = QLabel('Voltaje Actual')
        voltage_label.setFont(QFont('Arial', 14))
        voltage_label.setAlignment(Qt.AlignCenter)
        voltage_layout.addWidget(voltage_label)
        
        self.voltage_display = QLabel('0.00 V')
        self.voltage_display.setFont(QFont('Arial', 48, QFont.Bold))
        self.voltage_display.setAlignment(Qt.AlignCenter)
        self.voltage_display.setStyleSheet('color: #00ff00;')
        voltage_layout.addWidget(self.voltage_display)
        
        layout.addWidget(voltage_frame)
        
        # Estadísticas
        stats_frame = QFrame()
        stats_layout = QHBoxLayout(stats_frame)
        
        self.min_label = QLabel('Mín: 0.00V')
        self.min_label.setFont(QFont('Arial', 14))
        self.min_label.setStyleSheet('color: #00aaff;')
        
        self.max_label = QLabel('Máx: 0.00V')
        self.max_label.setFont(QFont('Arial', 14))
        self.max_label.setStyleSheet('color: #ff6600;')
        
        self.avg_label = QLabel('Prom: 0.00V')
        self.avg_label.setFont(QFont('Arial', 14))
        self.avg_label.setStyleSheet('color: #aa00ff;')
        
        stats_layout.addWidget(self.min_label)
        stats_layout.addWidget(self.max_label)
        stats_layout.addWidget(self.avg_label)
        
        layout.addWidget(stats_frame)
        
        # Gráfico
        self.chart = VoltageChart()
        layout.addWidget(self.chart)
        
        # Status
        self.status_label = QLabel('Estado: Esperando datos...')
        self.status_label.setFont(QFont('Arial', 12))
        self.status_label.setStyleSheet('color: #888888;')
        layout.addWidget(self.status_label)
    
    def update_voltage(self, voltage):
        self.voltage = voltage
        self.history.append(voltage)
        
        # Actualizar display
        self.voltage_display.setText(f'{voltage:.2f} V')
        
        # Color según voltaje
        if voltage < 11:
            self.voltage_display.setStyleSheet('color: #ff0000;')
        elif voltage > 15:
            self.voltage_display.setStyleSheet('color: #ff6600;')
        else:
            self.voltage_display.setStyleSheet('color: #00ff00;')
        
        # Estadísticas
        if self.history:
            min_v = min(self.history)
            max_v = max(self.history)
            avg_v = sum(self.history) / len(self.history)
            
            self.min_label.setText(f'Mín: {min_v:.2f}V')
            self.max_label.setText(f'Máx: {max_v:.2f}V')
            self.avg_label.setText(f'Prom: {avg_v:.2f}V')
        
        # Actualizar gráfico
        self.chart.update_chart(voltage)
        
        # Status
        self.status_label.setText(f'Estado: Conectado - Última lectura: {voltage:.2f}V')
        self.status_label.setStyleSheet('color: #00ff00;')


def main(args=None):
    rclpy.init(args=args)
    
    app = QApplication(sys.argv)
    
    # Señales para comunicación entre ROS y Qt
    signals = ROSSignals()
    
    # Nodo ROS2
    node = VoltageGUINode(signals)
    
    # Ventana principal
    window = MainWindow()
    signals.voltage_signal.connect(window.update_voltage)
    window.show()
    
    # Timer para spin de ROS2
    timer = QTimer()
    timer.timeout.connect(lambda: rclpy.spin_once(node, timeout_sec=0))
    timer.start(10)  # 10ms
    
    try:
        sys.exit(app.exec_())
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()