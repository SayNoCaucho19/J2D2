from setuptools import setup
import os
from glob import glob

package_name = 'voltage_monitor'

setup(
    name=package_name,
    version='1.0.0',
    packages=[package_name],
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
        (os.path.join('share', package_name, 'config'), 
            glob('config/*.yaml')),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='Tu Nombre',
    maintainer_email='tu@email.com',
    description='Monitor de voltaje FZ0430',
    license='MIT',
    entry_points={
        'console_scripts': [
           'mqtt_bridge_node = voltage_monitor.mqtt_bridge_node:main',
            'gui_node = voltage_monitor.gui_node:main',
        ],
    },
)