#include <WiFi.h>
#include <PubSubClient.h>
#include "esp_adc_cal.h"

// ===== CONFIGURACIÓN WIFI / MQTT (igual que antes) =====
const char* ssid = "Infinix";
const char* password = "contra122";
const char* mqtt_server = "10.218.2.97";
const int mqtt_port = 1883;
const char* mqtt_topic = "sensor/voltage";
const char* mqtt_client_id = "ESP32_FZ0430_1";

// ===== SENSOR =====
const int VOLTAGE_PIN = 34;             // ADC1_6 (GPIO34)
const float ADC_RESOLUTION = 4095.0;    // 12 bits
const float VOLTAGE_DIVIDER = 7.6;      // factor del FZ0430 (ajusta si cambio)
const int DEFAULT_VREF = 1100;          // valor por defecto de Vref (mV) si no calibras

// ===== CALIBRACIÓN =====
// Si después de medir con multímetro 7.00 V el ESP lee 9.00 V,
// calcula: CALIB_FACTOR = 7.00 / 9.00 = 0.777...
float CALIB_FACTOR = 0.66095; // pon aquí el factor calculado (ver instrucciones abajo)
float CALIB_OFFSET = 0.0; // opcional, en voltios (p.ej. 0.01)

// ===== MQTT y globales =====
WiFiClient espClient;
PubSubClient client(espClient);
unsigned long lastMsg = 0;
const long interval = 2000;

// ADC calibration struct
esp_adc_cal_characteristics_t adc_chars;

void setup_wifi() {
  Serial.println();
  Serial.print("🔌 Conectando a red WiFi: ");
  Serial.println(ssid);

  WiFi.begin(ssid, password);

  int intentos = 0;
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
    intentos++;
    if (intentos > 40) {
      Serial.println("\n❌ Error: no se pudo conectar al WiFi");
      return;
    }
  }

  Serial.println("\n✅ WiFi conectado correctamente!");
  Serial.print("📶 Dirección IP: ");
  Serial.println(WiFi.localIP());
}

void reconnect_mqtt() {
  while (!client.connected()) {
    Serial.print("🔄 Intentando conectar al broker MQTT... ");
    if (client.connect(mqtt_client_id)) {
      Serial.println("✅ Conectado al broker!");
      client.publish(mqtt_topic, "ESP32 conectado correctamente!");
    } else {
      Serial.print("❌ Falló, rc=");
      Serial.print(client.state());
      Serial.println(" -> Reintentando en 5 segundos...");
      delay(5000);
    }
  }
}

float readVoltageRawCalibrated() {
  // Leer raw ADC y convertir a mV usando esp_adc_cal (más fiable)
  uint32_t adc_reading = 0;
  // Promediar 10 lecturas
  for (int i = 0; i < 10; i++) {
    adc_reading += analogRead(VOLTAGE_PIN);
    delay(5);
  }
  adc_reading /= 10;

  // Convertir raw -> mV (usa la caracterización)
  uint32_t voltage_mV = esp_adc_cal_raw_to_voltage(adc_reading, &adc_chars); // mV

  // voltage at ADC pin (V)
  float v_adc = (float)voltage_mV / 1000.0;

  // voltage real = v_adc * divisor
  float v_real = v_adc * VOLTAGE_DIVIDER;

  // aplicar calibración (factor + offset)
  float v_calibrated = (v_real * CALIB_FACTOR) + CALIB_OFFSET;

  // debug en serial
  Serial.print("RAW=");
  Serial.print(adc_reading);
  Serial.print("  V_adc=");
  Serial.print(v_adc, 3);
  Serial.print(" V  V_real=");
  Serial.print(v_real, 3);
  Serial.print(" V  V_calib=");
  Serial.print(v_calibrated, 3);
  Serial.println(" V");

  return v_calibrated;
}

void setup() {
  Serial.begin(115200);
  delay(1000);
  Serial.println("=======================================");
  Serial.println("🚀 INICIANDO ESP32 FZ0430 Voltage Monitor");
  Serial.println("=======================================");

  // configurar ADC: resolución y atenuación
  analogReadResolution(12); // 0-4095
  analogSetPinAttenuation(VOLTAGE_PIN, ADC_11db); // permite rango ~0-3.6V en pin ADC

  // caracterizar ADC para que esp_adc_cal convierta raw->mV correctamente
  esp_adc_cal_characterize(ADC_UNIT_1, ADC_ATTEN_DB_11, ADC_WIDTH_BIT_12, DEFAULT_VREF, &adc_chars);

  pinMode(VOLTAGE_PIN, INPUT);

  setup_wifi();

  client.setServer(mqtt_server, mqtt_port);

  if (WiFi.status() == WL_CONNECTED) {
    reconnect_mqtt();
  }

  Serial.println("📡 Sistema listo para publicar voltajes!");
  Serial.println(">>> Si vas a calibrar, mide un voltaje conocido (p.ej. 7.00 V) con multímetro");
  Serial.println(">>> y ajusta CALIB_FACTOR = V_real_medido / V_ESP_leido (o dime y lo calculo yo).");
}

void loop() {
  if (!client.connected()) {
    reconnect_mqtt();
  }
  client.loop();

  unsigned long now = millis();
  if (now - lastMsg > interval) {
    lastMsg = now;
    float voltage = readVoltageRawCalibrated();

    char msg[50];
    snprintf(msg, 50, "%.2f", voltage);

    if (client.publish(mqtt_topic, msg)) {
      Serial.print("✅ Voltaje publicado: ");
      Serial.print(voltage, 2);
      Serial.println(" V");
    } else {
      Serial.println("⚠️ Error al publicar mensaje");
    }
  }
}
