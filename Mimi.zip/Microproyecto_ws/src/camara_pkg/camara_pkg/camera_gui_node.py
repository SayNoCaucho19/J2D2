
import rclpy
from rclpy.node import Node
import cv2
from PIL import Image, ImageTk
import tkinter as tk
import threading
import customtkinter


class CameraGUINode(Node):
    def __init__(self):
        super().__init__('camera_gui_node')
        self.url = "http://192.168.52.1:81/stream"  # Stream ESP32-CAM
        self.get_logger().info(f"📷 Nodo GUI iniciado, conectando a {self.url}")

        # Tkinter en un hilo separado
        self.gui_thread = threading.Thread(target=self.start_gui, daemon=True)
        self.gui_thread.start()

    def start_gui(self):
        self.root = tk.Tk()
        self.root.title("🚤 Robot Acuático - Cámara")
        self.root.geometry("900x900")  # Ventana cuadrada
        self.root.configure(bg="#2c2c2c")  # Fondo gris oscuro

        # Título
        title = tk.Label(
            self.root,
            text="🚤 Robot Acuático - Cámara en Vivo",
            font=("Arial", 18, "bold"),
            fg="white",
            bg="#2c2c2c"
        )
        title.pack(pady=10)

        # Label para el video
        self.video_label = tk.Label(self.root, bg="#2c2c2c")
        self.video_label.pack(expand=True, fill="both", padx=20, pady=20)

        # Captura de video
        self.cap = cv2.VideoCapture(self.url)

        self.update_frame()
        self.root.protocol("WM_DELETE_WINDOW", self.on_close)
        self.root.mainloop()

    def update_frame(self):
        # limpiar buffer: leer varias veces para evitar delay
        ret, frame = None, None
        for _ in range(2):
            ret, frame = self.cap.read()

        if ret:
            frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)

            # mantener aspecto original (4:3) dentro del contenedor cuadrado
            label_w = self.video_label.winfo_width()
            label_h = self.video_label.winfo_height()

            if label_w > 0 and label_h > 0:
                aspect_ratio = frame.shape[1] / frame.shape[0]  # ancho/alto
                if label_w / label_h > aspect_ratio:
                    # ajusta por altura
                    new_h = label_h
                    new_w = int(new_h * aspect_ratio)
                else:
                    # ajusta por ancho
                    new_w = label_w
                    new_h = int(new_w / aspect_ratio)

                # 🔧 Evitar errores de tamaño cero
                if new_w > 0 and new_h > 0:
                    frame = cv2.resize(frame, (new_w, new_h))

            img = Image.fromarray(frame)
            imgtk = ImageTk.PhotoImage(image=img)
            self.video_label.imgtk = imgtk
            self.video_label.configure(image=imgtk)

        if hasattr(self, "root"):
            self.root.after(20, self.update_frame)  # refresco más estable


    def on_close(self):
        self.cap.release()
        if hasattr(self, "root"):
            self.root.destroy()
        self.get_logger().info("✅ Ventana cerrada, nodo detenido.")


def main(args=None):
    rclpy.init(args=args)
    node = CameraGUINode()

    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == "__main__":
    main()
